<template>
  <div id="app">
    <TechCrunchNews />
  </div>
</template>

<script>
import TechCrunchNews from './components/TechCrunchNews.vue';

export default {
  components: {
    TechCrunchNews,
  },
};
</script>

<style>

</style>
