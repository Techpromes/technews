<template>
  <div>
    <header class="site-header">
      <h1 class="site-title">TechCrunch News</h1>
      <!-- Add navigation links or other relevant content as needed -->
    </header>

    <div class="tech-crunch-news">
      <h2 class="page-title">Latest News</h2>
      <ul class="article-list">
        <li v-for="article in articles" :key="article.title" class="article-item">
          <div class="article-content">
            <h3 class="article-title">
              <a :href="article.url" target="_blank">{{ article.title }}</a>
            </h3>
            <p class="article-description">{{ article.description }}</p>
          </div>
        </li>
      </ul>
    </div>

    <section class="follow-our-news">
      <div class="container">
        <h2>Follow Our News</h2>
        <div class="social-icons">
        <a href="https://twitter.com/Tommymaks123" target="_blank">  <img src=".././assets/twitter.png" alt="Twitter" width="50px" height="50px"></a>
		<a href="https://www.instagram.com/tommymaks123" target="_blank"> <img src=".././assets/instagram.png" alt="Instagram" width="20px" height="20px"></a>
          <!-- Add more social media icons as needed -->
        </div>
      </div>
    </section>

    <section class="subscribe-newsletter">
      <div class="container">
        <h2>Subscribe to Our Newsletter</h2>
        <form>
          <input type="email" placeholder="Enter your email" required>
          <button type="submit">Subscribe</button>
        </form>
      </div>
    </section>

    <footer class="site-footer">
      <p>&copy; 2023 TechCrunch News. All rights reserved.</p>
    </footer>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      articles: [],
    };
  },
  mounted() {
    const apiKey = 'b42a8b5fc48243a387c3b7868c3bd67d';
    const apiUrl = 'https://newsapi.org/v2/top-headlines?sources=techcrunch';

    axios.get(apiUrl, { headers: { 'X-Api-Key': apiKey } })
      .then(response => {
        this.articles = response.data.articles;
      })
      .catch(error => {
        console.error('Error fetching TechCrunch news:', error);
      });
  },
};
</script>

<style scoped>
/* Your existing styles */

.site-header {
  background-color: #333;
  color: #fff;
  padding: 10px;
  text-align: center;
}

.site-title {
  font-size: 2em;
}

.follow-our-news,
.subscribe-newsletter {
  background-color: #f8f8f8;
  padding: 40px 0;
  text-align: center;
}

social-icons {
  display: flex;
  justify-content: center;
  align-items: center;
}

.social-icons a {
  margin: 0 10px;
}

.social-icons img {
  border-radius: 50%;
   width: 30px; /* Adjust the width as needed */
  height: 30px; /* Adjust the height as needed */
  margin: 0 5px; /* Add margin for spacing between icons */
}

.subscribe-newsletter form {
  margin-top: 20px;
}
.subscribe-newsletter {
  margin-bottom: 40px; /* Adjust as needed */
}

.site-footer {
  background-color: #333;
  color: #fff;
  text-align: center;
  padding: 10px;
  position: fixed;
  bottom: 0;
  width: 100%;
}
.subscribe-newsletter .container {
  text-align: center;
}

.subscribe-newsletter h2 {
  font-size: 1.8em;
  margin-bottom: 15px;
  color: #333;
}

.form-group {
  display: flex;
  justify-content: center;
  align-items: center;
}

input[type="email"] {
  padding: 10px;
  width: 250px;
  border: 1px solid #ddd;
  border-radius: 5px;
  margin-right: 10px;
}

button {
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
</style>
